################-FSE-###############
#-Ibraheem Aloran and Manroop Gill-#
###########-Tower Defense-##########
from pygame import*
from pygame.locals import*
from math import*
from random import*
from random import randint
def fadeIn(surface,logo):
    "Screen starts black and image slowly gains colour"
    for i in range(255//4):
        surface.blit(logo,(0,0))
        layer=Surface((surface.get_width(),surface.get_height()))
        layer.set_alpha(255-i*4)
        surface.blit(layer,(0,0))
        display.flip()

def fadeOut(surface,logo):
    "Image loses colour and fades to black"
    for i in range(255//4):
        surface.blit(logo,(0,0))
        layer=Surface((surface.get_width(),surface.get_height()))
        layer.set_alpha(i*4) 
        surface.blit(layer,(0,0))
        display.flip()
#Pictures
strtSc = image.load("pic/9222382647_eaa12907c5_o.jpg")
smallstrtSc = transform.scale(strtSc,(1100,700))
mainSc = image.load("pic/zombie-background.jpg")
smallmainSc = transform.scale(mainSc,(1100,700))
gameSc = image.load("pic/8_paths_simple.jpg")
smallgameSc = transform.scale(gameSc,(1100,700))
instrucSc=image.load("pic/howSc.png")
heart = image.load("pic/coracaozinho-para-o-luiz-otavio.png")
smallheart = transform.scale(heart,(20,20))
coins= image.load("pic/coins.png")
smallcoin = transform.scale(coins,(20,20))
towermenu=image.load("pic/towersmenu.png")
loadSc = image.load("pic/9222382647_eaa12907c5_o.png")
smallloadSc = transform.scale(loadSc,(1100,700))
nukePic = image.load("pic/radioactive-24022_960_720.png")
smallnukePic = transform.scale(nukePic,(50,50))
blueball = image.load("pic/laserb30.png")
#Buttons
playRect = Rect(650,200,450,500)
howRect = Rect(0,200,450,500)
backRect = Rect(40,20,100,100)

towers = [Rect(90,610,80,90),Rect(170,610,80,90),Rect(250,610,80,90),
          Rect(330,610,80,90),Rect(410,610,80,90), Rect(490,610,80,90),
          Rect(570,610,80,90),Rect(650,610,80,90),Rect(730,610,80,90),
          Rect(810,610,80,90),Rect(890,610,80,90)]

nukeRect = Rect(1000,630,50,50)
#damage = [[10,0.4],[15,0.6],[2





init()

screen = display.set_mode((1100,700))
mode = "start"

weapons = []
for i in range(1,6):
    weapons.append(image.load("pic/tower"+str(i)+".png"))

#FONTS

font.init()
zombie1Font = font.SysFont("Deanna", 195)
zombie2Font = font.SysFont("Deanna", 200)
zombie3Font = font.SysFont("Deanna", 150)
zombie4Font = font.SysFont("Deanna", 155)
zombie5Font = font.SysFont("Deanna", 30)





mixer.music.load("pic/ANTM Fade Sound Effect.mp3")

myClock = time.Clock()

#VARIABlES AND LISTS

up = []
down = []
right = []
boss = []
frame = 0
spot = 0
y = 0
#l = 0
heart = 50
money = 500
wave = 1
tower = None
tool = "none"
active = []
cord = []
coord = []
X=0
Y=1
VY=2
DELAY=2
FRAME=3
init()
boomPics = []
guy = [250,0]
bombs = []              # list of [x,y,timeCounter, frame]
dropCount = 0
b = a = 500

placeRect = ((0,0),(0,435),(95,435),(95,130),(285,130),(285,435),(380,435),(380,130),(570,130),(570,435),(670,435),(670,130),(860,130),(860,435),(955,435),(955,130),(1100,130),(1100,0))

path = [(105,430),(105,120),(250,120),(250,430),(395,430),(395,120),(535,120),(535,430),(680,430),(680,120),(825,120),(825,430),(970,430),(970,120),(1100,120)]
## the coordinates of where the enemymoves or turns at
move = right #starts off going to the right

enemyX,enemyY = (0,430)
col = (227, 171, 96)
def moveEnemy(x,v,h):
    global  frame, spot, move, enemyX, enemyY, y, myClock
    pos = (enemyX,enemyY)
    cycle = [up,right,down,right] ##pattern of the zombie moving through the map
    mode = "alive"
    if h <= 0: ##health of enemy
        mode = "dead"
    if mode == "alive":
    #MOVEMENT AND SPEED    
        for i in path: 
            if pos == i:
                
                move = cycle[y]
                y += 1
                if y == 4:
                    y = 0
        if move == right:
            frame =0
            enemyX += v
            
        elif move == up:
            frame = 1
            enemyY -= v

        elif move == down:
            frame = 2
            enemyY += v
            
        screen.blit(x[frame][int(spot)],(enemyX,enemyY)) #blits in the frame and speed of zombie
        spot += 0.25
        if spot == 2:
            spot = 0

        
    

def setTow():
    global weapons, mx, my, mb, tower, tool, active, towers, enemyX, enemyY
    ang = 0
    c = 0
    radius = 110
    for tow in towers:
        if tow.collidepoint(mx,my):
            draw.rect(screen,(0),tow,0)
    if e.type == MOUSEBUTTONDOWN:
        for tow in towers:
            if tow.collidepoint(mx,my):
                tool = "drag"
                num = towers.index(tow)
                tower = weapons[num]
        
    if tool == "drag":
        screen.blit(tower,(mx-tower.get_width()//2,my-tower.get_height()//2))
    if e.type == MOUSEBUTTONUP and tool == "drag":
        tool = "none"
        pos = [mx,my]
        active.append(tower)
        cord.append(pos)
        coord.append(pos)

        
    
        
    
    for act in active:
        numb = active.index(act)
        x = cord[numb][0]
        y = cord[numb][1]
        w = coord[numb][0]
        l = coord[numb][1]
        if enemyX > x and enemyY > y:
            a = enemyX-x
            b = enemyY-y
            ang = 180+(degrees(atan2(a,b)))
            c = ((a**2)+(b**2))**0.5
        if enemyX < x and enemyY > y:
            a = x-enemyX
            b = enemyY-y
            ang = 180-(degrees(atan2(a,b)))
            c = ((a**2)+(b**2))**0.5
        if enemyX < x and enemyY < y:
            a = x-enemyX
            b = y-enemyY
            ang = degrees(atan2(a,b))
            c = ((a**2)+(b**2))**0.5
        if enemyX > x and enemyY < y:
            a = enemyX-x
            b = y-enemyY
            ang = 0-(degrees(atan2(a,b)))
            c = ((a**2)+(b**2))**0.5
        #draw.circle(screen,(0),(x,y),radius)
        newTower = transform.rotate(act,ang)
        mode = "nothing"
        if c <= radius:
            mode = "attack"
        if mode ==  "nothing":
            screen.blit(act,(x-act.get_width()//2,y-act.get_height()//2))
        if mode == "attack":
            screen.blit(newTower,(x-newTower.get_width()//2,y-newTower.get_height()//2))
           # screen.blit(bluePic,(x-newTower.get_width()//2+vx,y-newTower.get_height()//2+vy))
            
            
            
            
            



    draw.polygon(screen,(0),((0,0),(0,435),(95,435),(95,130),(285,130),(285,435),(380,435),(380,130),(570,130),(570,435),(670,435),(670,130),(860,130),(860,435),(955,435),(955,130),(1100,130),(1100,0)),3)


    
    screen.blit(weapons[0],(110,620))
    screen.blit(weapons[1],(190,620))
    screen.blit(weapons[2],(270,620))
    screen.blit(weapons[3],(350,620))
    screen.blit(weapons[4],(425,620))
    screen.blit(weapons[5],(510,620))
    screen.blit(weapons[6],(590,620))
    screen.blit(weapons[7],(660,620))
    screen.blit(weapons[8],(740,620))
    screen.blit(weapons[9],(820,620))
    screen.blit(weapons[10],(900,620))
    print(mx,my)         
for i in range(28):
    boomPics += [image.load("images\\Explode-05_frame_"+str(i)+".gif")]


def drawScene(screen,guy, bombs):    
    for bomb in bombs:
        if bomb[3]==0:
            draw.circle(screen,(255,0,0), (bomb[0]+120,bomb[1]+90),5)
        screen.blit(boomPics[bomb[FRAME]], bomb[:2])        
    display.flip()

def advanceBombs(bombs):
    rem = []
    for bomb in bombs:       
        bomb[DELAY]+=1
        if bomb[DELAY] > 90 and bomb[DELAY]%5==0: # the DELAY acts as a wait to start the 
            bomb[FRAME]+=1                          
            if bomb[FRAME]==28:
                rem.append(bomb)
    for b in rem:       # we can't remove from bombs as we traverse it (it will crash)
        bombs.remove(b) # so we add the dead bombs to a list the remove them after.
            


def moveGuy(guy,dropCount):
    mode = "safe"
    draw.rect(screen,(0),nukeRect,2)
    if nukeRect.collidepoint(mx,my) and mb[0] == 1:
        mode = "bomb"
    

    if mode == "bomb" and dropCount == 0:
        bombs.append([50,100,0,0])
        bombs.append([275,100,0,0])
        bombs.append([500,100,0,0])
        bombs.append([800,100,0,0])
        bombs.append([275,400,0,0])
        bombs.append([500,400,0,0])
        bombs.append([800,400,0,0])
        bombs.append([50,400,0,0])
        bombs.append([275,250,0,0])
        bombs.append([500,250,0,0])
        bombs.append([800,250,0,0])
        bombs.append([50,250,0,0])
        
        dropCount = 5
    if dropCount > 0:
        dropCount-=1
    return dropCount

def shoot(x,y):
    pass
    
            

            

def start(): #this screen is only there for a brief second and just fades in and out
    global mode, running, mb
    mixer.music.play(-1)
    fadeIn(screen,smallloadSc)
    fadeOut(screen,smallloadSc)
    mixer.music.stop()
    mode = "main"
        
    display.flip()
    

                

def main():
    global mode, mx, my, mb, running, spot
    mixer.music.load("pic/MainMusic.mp3")
    mixer.music.play(-1)
    
    screen.blit(smallmainSc,(0,0))
    #CREATING TEXTS
    ZPic = zombie1Font.render("ZOMBIE", True,(218,165,32))
    DPic = zombie1Font.render("DEFENSE", True,(218,165,32))
    Z2Pic = zombie2Font.render("ZOMBIE", True,(0,0,0))
    D2Pic = zombie2Font.render("DEFENSE", True,(0,0,0))
    playPic = zombie3Font.render("PLAY", True,(218,165,32))
    play2Pic = zombie4Font.render("PLAY", True,(0,0,0))
    howPic = zombie3Font.render("HOW TO", True,(218,165,32))
    how2Pic = zombie4Font.render("HOW TO", True,(0,0,0))
    
    #BLITTING IN THE TeXTS
    screen.blit(Z2Pic,(20,-50))
    screen.blit(D2Pic,(640,-50))
    screen.blit(ZPic,(30,-50))
    screen.blit(DPic,(650,-50))
    screen.blit(playPic,(785,300))
    screen.blit(playPic,(85,330))
    screen.blit(howPic,(35,250))
    if playRect.collidepoint(mx,my):
        screen.blit(play2Pic,(780,300))
        screen.blit(playPic,(785,300))
        if mb[0] == 1:
            mode = "game"
            mixer.music.stop()
           
                
    if howRect.collidepoint(mx,my):
        screen.blit(how2Pic,(30,250))
        screen.blit(howPic,(35,250))
        screen.blit(play2Pic,(80,330))
        screen.blit(playPic,(85,330))
        if mb[0] == 1:
            mode = "how"        
    display.flip()  


def how():
    global mode,running,mb, mx, my
    screen.blit(instrucSc,(0,0))
    backPic = zombie3Font.render("BACK", True, (218,165,32)) #renders text for buttons
    back2pic = zombie4Font.render("BACK", True, (0,0,0))
    screen.blit(backPic,(30,20))
    if backRect.collidepoint(mx,my): #hovering over it changes the colour
        screen.blit(backPic,(30,20))
        screen.blit(back2pic,(35,20))

        if mb[0] == 1:       
            mode = "main"
    display.flip()

    
def game(): #Main game function where the images blit, stuff renders, or functions begin.
    global mode, mx, my, mb, running, tool, dropCount, heart
    #print(tool)
    screen.blit(smallgameSc,(0,0))
    screen.blit(smallnukePic,(1000,630))
    back = screen.copy()
    screen.blit(towermenu,(0,600))
    screen.blit(smallheart,(976,30))
    screen.blit(smallcoin,(975, 60))
    moveEnemy(zombie1,zombie1[-2],zombie1[-1])
    setTow()
    dropCount = moveGuy(guy,dropCount)
    advanceBombs(bombs)
    drawScene(screen, guy, bombs)
    myClock.tick(60)
    heart-=1
    heartP = zombie5Font.render(str(heart), True, (0,0,0))
    moneyP = zombie5Font.render(str(money), True, (0,0,0))
    screen.blit(moneyP,(1000,50))
    screen.blit(heartP,(1000,20))

   

    
    display.flip()
    
    
    
    

def upload(name,folder,pics):
    for i in range(3):
        up = []
        down = []
        right = []
        name = []
        
for i in range(3):
    up.append(image.load("Zombie1WalkingU/Zombie1WalkingU" + str(i)+".png"))
    down.append(image.load("Zombie1WalkingD/Zombie1WalkingD" + str(i) + ".png"))
    right.append(image.load("Zombie1WalkingR/Zombie1WalkingR" + str(i) + ".png"))

##for i in range(4):
##    dog = [[image.load(("


#putting all images into a list so we can easily put them in the game as a sprite
zombieBoss = []
zombie1 = []
zombie1.append(right)#right list
zombie1.append(up)# up list
zombie1.append(down)#down list
zombie1.append(1)
zombie1.append(10)




running = True
while running:
    click = False
    for e in event.get():
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            if e.button == 1:
                click = True

    mx,my = mouse.get_pos()
    mb = mouse.get_pressed()
    
    #if clicking on the functions it changes the mode to that speicifc function
    if mode == "start":
        start()
    if mode == "main":
        main()
    if mode == "game":
        game()
    if mode == "how":
        how()


    oldx = mx
    oldy = my
    display.flip()
quit()
