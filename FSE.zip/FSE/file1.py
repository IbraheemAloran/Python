#File i/o(input/output)
#file1.py
inFile = open("names","r")
names = inFile.readlines()
for name in names:
    print("Hello",name)
inFile.close()


