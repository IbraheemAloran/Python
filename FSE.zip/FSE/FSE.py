################-FSE-###############
#-Ibraheem Aloran and Manroop Gill-#
###########-Tower Defense-##########
from pygame import*
from pygame.locals import*
from math import*
from random import*
from random import randint
import time
def fadeIn(surface,logo):
    "Screen starts black and image slowly gains colour"
    for i in range(255//4):
        surface.blit(logo,(0,0))
        layer=Surface((surface.get_width(),surface.get_height()))
        layer.set_alpha(255-i*4)
        surface.blit(layer,(0,0))
        display.flip()

def fadeOut(surface,logo):
    "Image loses colour and fades to black"
    for i in range(255//4):
        surface.blit(logo,(0,0))
        layer=Surface((surface.get_width(),surface.get_height()))
        layer.set_alpha(i*4)
        surface.blit(layer,(0,0))
        display.flip()
#Pictures
instrucSc=image.load("pic/howSc.png")
strtSc = image.load("pic/9222382647_eaa12907c5_o.jpg")
smallstrtSc = transform.scale(strtSc,(1100,700))
mainSc = image.load("pic/zombie-background.jpg")
smallmainSc = transform.scale(mainSc,(1100,700))
gameSc = image.load("pic/8_paths_simple.jpg")
smallgameSc = transform.scale(gameSc,(1100,700))
heart = image.load("pic/coracaozinho-para-o-luiz-otavio.png")
smallheart = transform.scale(heart,(20,20))
towermenu=image.load("pic/towersmenu.png")
loadSc = image.load("pic/9222382647_eaa12907c5_o.png")
smallloadSc = transform.scale(loadSc,(1100,700))
nukePic = image.load("pic/radioactive-24022_960_720.png")
smallnukePic = transform.scale(nukePic,(50,50))
coinPic = image.load("pic/coins.png")
smallcoin = transform.scale(coinPic,(20,20))
bluePic = image.load("pic/laserb30.png")
#Buttons
playRect = Rect(650,200,450,500)
howRect = Rect(0,200,450,500)
backRect = Rect(20,60,300,150)
startRect = Rect(1040,30,50,50)
bombRect = Rect(1000,630,50,50)

towers = [Rect(90,610,80,90),Rect(250,610,80,90),
          Rect(410,610,80,90),Rect(570,610,80,90),Rect(730,610,80,90)]

nukeRect = Rect(1000,630,50,50)





init()

screen = display.set_mode((1100,700))
mode = "start"

weapons = []
for i in range(1,6):
    weapons.append(image.load("pic/tower"+str(i)+".png"))
bomb = []
for k in range(15):
    bomb.append(image.load("pic/explosion-sprite" + str(k)+".png"))

font.init()
zombie1Font = font.SysFont("Deanna", 195)
zombie2Font = font.SysFont("Deanna", 200)
zombie3Font = font.SysFont("Deanna", 150)
zombie4Font = font.SysFont("Deanna", 155)
zombie5Font = font.SysFont("Deanna", 30)





mixer.music.load("pic/ANTM Fade Sound Effect.mp3")


zombie1 = []
zombie2 = []
zombie3 = []
zombie4 = []
zombie5 = []
zombie6 = []
zombie7 = []
zombies = [zombie1,zombie2,zombie3,zombie4,zombie5,zombie6,zombie7]
state = "add"
frame = 0
spot = 0
y = 0
#l = 0
heart = 50
money = 200
wave = 1
tower = None
tool = "none"
bullets = []
active = []
inUse = []
cord = []
vis = "stop"
time = 0
sec = 0
verse = "safe"

placeRect = ((0,0),(0,435),(95,435),(95,130),(285,130),(285,435),(380,435),(380,130),(570,130),(570,435),(670,435),(670,130),(860,130),(860,435),(955,435),(955,130),(1100,130),(1100,0))


path = [(105,430),(105,120),(250,120),(250,430),(395,430),(395,120),(535,120),(535,430),(680,430),(680,120),(825,120),(825,430),(970,430),(970,120),(1100,120)]
move = "right"
pos=enemyX,enemyY = (0,430)

col = (227, 171, 96)
def moveEnemy(x,v,health):
    global  frame, spot, move, enemyX, enemyY, y, myClock, wave, zombies, state, heart, money
    if len(inUse) > 0:
        pos = (enemyX,enemyY)
        cycle = ["up","right","down","right"]
        mode = "alive"
        if health <= 0:
            mode = "dead"
        if mode == "alive":
            for i in path:
                if pos == i:
                    move = cycle[y]
                    y += 1
                    if y == 4:
                        y = 0
        
            if move == "right":
                frame = 0
                enemyX += v
                
            elif move == "up":
                frame = 3
                enemyY -= v

            elif move == "down":
                frame = 6
                enemyY += v
            
                    
            screen.blit(x[frame+int(spot)],(pos))
            spot += 0.25
            if spot == 2:
                spot = 0

        if pos == path[-1]:
                heart -= len(inUse)
                wave += 1
                money += 50
                for j in range(len(inUse)):
                    del inUse[-1]
    if mode == "dead":
        del inUse[randint(0,len(inUse))]
    
    
    #print(pos)




def setZombie():
    global wave, zombies, state, sec
    sec += 0.25
    if sec == 20:
        state = "add"
        sec = 0

    if state == "add":
        inUse.append(zombies[randint(0,6)])
        state = "done"

    if len(inUse) > 0:
        for U in inUse:
            moveEnemy(U,U[-2],U[-1])
    print(len(inUse))
    
    
           

         
    
    
    
    














def setTow():
    global weapons, mx, my, mb, tower, tool, active, towers, enemyX, enemyY, money, time
    ang = 0
    c = 0
    radius = 110
    for tow in towers:
        if tow.collidepoint(mx,my):
            draw.rect(screen,(0),tow,0)
    if money >= 100:
        if e.type == MOUSEBUTTONDOWN:
            for tow in towers:
                if tow.collidepoint(mx,my):
                    tool = "drag"
                    num = towers.index(tow)
                    tower = weapons[num]
        
    if tool == "drag":
        screen.blit(tower,(mx-tower.get_width()//2,my-tower.get_height()//2))
    if e.type == MOUSEBUTTONUP and tool == "drag":
        money -= 100
        tool = "none"
        pos = [mx,my]
        active.append(tower)
        cord.append(pos)

        
    
        
    
    for act in active:
        numb = active.index(act)
        x = cord[numb][0]
        y = cord[numb][1]
        
        if enemyX > x and enemyY > y:
            a = enemyX-x
            b = enemyY-y
            ang = 180+(degrees(atan2(a,b)))
            c = ((a**2)+(b**2))**0.5
            vx = 10*a/c
            vy = 10*b/c
        if enemyX < x and enemyY > y:
            a = x-enemyX
            b = enemyY-y
            ang = 180-(degrees(atan2(a,b)))
            c = ((a**2)+(b**2))**0.5
            vx = 10*a/c
            vy = 10*b/c
        if enemyX < x and enemyY < y:
            a = x-enemyX
            b = y-enemyY
            ang = degrees(atan2(a,b))
            c = ((a**2)+(b**2))**0.5
            vx = 10*a/c
            vy = 10*b/c
        if enemyX > x and enemyY < y:
            a = enemyX-x
            b = y-enemyY
            ang = 0-(degrees(atan2(a,b)))
            c = ((a**2)+(b**2))**0.5
            vx = 10*a/c
            vy = 10*b/c
        #draw.circle(screen,(0),(x,y),radius)
        newTower = transform.rotate(act,ang)
        mode = "nothing"
        if c <= radius:
            mode = "attack"
        if mode ==  "nothing":
            screen.blit(act,(x-act.get_width()//2,y-act.get_height()//2))
        if mode == "attack":
            screen.blit(newTower,(x-newTower.get_width()//2,y-newTower.get_height()//2))
            if len(inUse) != 0:
                time += 0.25
                if time == 10:
                    money += 20
                    del inUse[-1]
                    time = 0
           
    
            #screen.blit(bluePic,(x-newTower.get_width()//2+vx,y-newTower.get_height()//2+vy))
##        print(time)
            
            
        
            
            
            



    draw.polygon(screen,(0),((0,0),(0,435),(95,435),(95,130),(285,130),(285,435),(380,435),(380,130),(570,130),(570,435),(670,435),(670,130),(860,130),(860,435),(955,435),(955,130),(1100,130),(1100,0)),3)


    
    screen.blit(weapons[0],(110,620))
    screen.blit(weapons[1],(270,620))
    screen.blit(weapons[2],(425,620))
    screen.blit(weapons[3],(590,620))
    screen.blit(weapons[4],(740,620))
    
             

    
def start():
    global mode, running, mb
    mixer.music.play(-1)
    fadeIn(screen,smallloadSc)
    fadeOut(screen,smallloadSc)
    mixer.music.stop()
    mode = "main"
        
    display.flip()
    

def main():
    global mode, mx, my, mb, running, spot
    mixer.music.load("pic/MainMusic.mp3")
    
    screen.blit(smallmainSc,(0,0))
    ZPic = zombie1Font.render("ZOMBIE", True,(218,165,32))
    DPic = zombie1Font.render("DEFENSE", True,(218,165,32))
    Z2Pic = zombie2Font.render("ZOMBIE", True,(0,0,0))
    D2Pic = zombie2Font.render("DEFENSE", True,(0,0,0))
    playPic = zombie3Font.render("PLAY", True,(218,165,32))
    play2Pic = zombie4Font.render("PLAY", True,(0,0,0))
    howPic = zombie3Font.render("HOW TO", True,(218,165,32))
    how2Pic = zombie4Font.render("HOW TO", True,(0,0,0))
    screen.blit(Z2Pic,(20,-50))
    screen.blit(D2Pic,(640,-50))
    screen.blit(ZPic,(30,-50))
    screen.blit(DPic,(650,-50))
    screen.blit(playPic,(785,300))
    screen.blit(playPic,(85,330))
    screen.blit(howPic,(35,250))
    if playRect.collidepoint(mx,my):
        screen.blit(play2Pic,(780,300))
        screen.blit(playPic,(785,300))
        if mb[0] == 1:
            mode = "game"
            mixer.music.stop()
           
                
    if howRect.collidepoint(mx,my):
        screen.blit(how2Pic,(30,250))
        screen.blit(howPic,(35,250))
        screen.blit(play2Pic,(80,330))
        screen.blit(playPic,(85,330))
        if mb[0] == 1:
            mode = "how"
    
    display.flip()



def how():
    global mode,running,mb, mx, my
    screen.blit(instrucSc,(0,0))
    backPic = zombie3Font.render("BACK", True, (218,165,32))
    back2Pic = zombie4Font.render("BACK", True, (0,0,0))
    screen.blit(back2Pic,(30,20))
    if backRect.collidepoint(mx,my):
        screen.blit(backPic,(35,20))
        screen.blit(back2Pic,(30,20))

        if mb[0] == 1:       
            mode = "main"
    display.flip()


    
def game():
    global mode, mx, my, mb, running, tool, dropCount, vis, verse
    screen.blit(smallgameSc,(0,0))
    screen.blit(smallnukePic,(1000,630))
    back = screen.copy()
    screen.blit(towermenu,(0,600))
    screen.blit(smallheart,(970,30))
    screen.blit(smallcoin,(970,60))
    draw.polygon(screen,(0,0,255),((1045,40),(1045,90),(1065,65)),2)
    draw.polygon(screen,(0,0,255),((1065,40),(1065,90),(1085,65)),2)
    if startRect.collidepoint(mx,my) and mb[0] == 1:
        draw.polygon(screen,(0,0,255),((1045,40),(1045,90),(1065,65)),0)
        draw.polygon(screen,(0,0,255),((1065,40),(1065,90),(1085,65)),0)
        vis = "play"
    if vis == "play":
        setZombie()
        #moveEnemy()
    setTow()

    heartP = zombie5Font.render(str(heart), True, (0,0,0))
    moneyP = zombie5Font.render(str(money), True, (0,0,0))
    waveP = zombie5Font.render(str(wave), True, (0,0,0))
    wavePic = zombie5Font.render("WAVE:", True, (0,0,0))
    screen.blit(moneyP,(1000,50))
    screen.blit(heartP,(1000,20))
    screen.blit(waveP,(1000,80))
    screen.blit(wavePic,(930,80))


    display.flip()
    
    




for p in range(9):
    zombie1.append(image.load("Zombie1WalkingR/Zombie1WalkingR" + str(p) + ".png"))
    zombie2.append(image.load("zombie1R/zombie1R" + str(p) + ".png"))
    zombie3.append(image.load("zombie3R/zombie3R" + str(p) + ".png"))
    zombie4.append(image.load("skel1R/skel1R" + str(p) + ".png"))
    zombie5.append(image.load("zombie4R/zombie4R" + str(p) + ".png"))
    zombie6.append(image.load("zombie5R/zombie5R" + str(p) + ".png"))
    zombie7.append(image.load("zombieR/zombieR" + str(p) + ".png"))
    

##stats = [[1,10],[2.5,10],[2.5,10],[5,10],[1,10],[1,20],[2.5,15]]
zombie1.append(1)
zombie1.append(10)
zombie2.append(1)
zombie2.append(10)
zombie3.append(1)
zombie3.append(10)
zombie4.append(1)
zombie4.append(10)
zombie5.append(1)
zombie5.append(10)
zombie6.append(1)
zombie6.append(20)
zombie7.append(1)
zombie7.append(15)


running = True
while running:
    click = False
    for e in event.get():
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            if e.button == 1:
                click = True
        
    

        
                
                

    mx,my = mouse.get_pos()
    mb = mouse.get_pressed()
    
    
    if mode == "start":
        start()
    if mode == "main":
        main()
    if mode == "game":
        game()
    if mode == "how":
        how()


    oldx = mx
    oldy = my
    display.flip()
quit()





































        
