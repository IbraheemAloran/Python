from pygame import*
from random import*
from math import*
from tkinter import*
screen = display.set_mode((1200,900))
#PICTURES
colorPic = image.load("Goomba/atari-256-colour-palette.png")
smallcolorPic = transform.scale(colorPic,(180,180))
print(1)  #used to see where program slows down
marioPic = image.load("Mario/386px-MarioNSMBWii.PNG")
warioPic = image.load("Goomba/SM3DL2_Wario_2.png")
smallwarioPic = transform.scale(warioPic,(150,150))
woodPic = image.load("Goomba/blank-wood-sign-clip-art-at-clker-com-vector-clip-art-online-cdkVvy-clipart.png")
smallwoodPic = transform.scale(woodPic,(170,160))
print(2)
smallmarioPic = transform.scale(marioPic,(150,150))
#image.save(smallmarioPic,"Mario/386px-Mario.PNG")
smallbackPic = image.load("Goomba/New-super-mario-bros.jpg")
bluePic = image.load("Goomba/Ice_Flower_Artwork_-_New_Super_Mario_Bros._Wii.png")
smallbluePic = transform.scale(bluePic,(150,150))
print(3)
backPic = transform.scale(smallbackPic,(1200,900))
#image.save(smallbackPic,"Goomba/New-super-mario-bros.png")
luigiPic = image.load("Luigi/SM3DL2_Luigi.png")
smallluigiPic = transform.scale(luigiPic,(150,150))
print(4)
bowserPic = image.load("Bowser/Bowser_-_Super_Smash_Bros..png")
smallbowserPic = transform.scale(bowserPic,(150,160))
kamekPic = image.load("Goomba/Fig_20_kamek.png")
smallkamekPic =transform.scale(kamekPic,(150,150))
yoshiPic = image.load("Goomba/Yoshi.png")
smallyoshiPic = transform.scale(yoshiPic,(140,160))
print(5)
peachPic = image.load("Peach/Princess_Peach_NSMBW.png")
smallpeachPic = transform.scale(peachPic,(120,150))
redPic = image.load("Goomba/Fire_Flower_Mario.png")
smallredPic = transform.scale(redPic,(150,150))
print(6)
toadPic = image.load("Toad/captain_toad_transparent_by_mach_7-d9h8jcl.png")
smalltoadPic = transform.scale(toadPic,(150,150))
starPic = image.load("Goomba/200px-StarMK8.png")
smallstarPic = transform.scale(starPic,(150,150))
mushPic = image.load("Goomba/Mushroom.png")
smallmushPic = transform.scale(mushPic,(150,150))
print(7)
toadettePic = image.load("Toad/Toadette_-_Mario_Party_10.png")
smalltoadettePic = transform.scale(toadettePic,(150,150))
waluigiPic = image.load("Goomba/waluigirender.png")
smallwaluigiPic = transform.scale(waluigiPic,(150,150))
print(8)
pencilPic = image.load("Icons/pencil-icon-512-17.png")
smallpencilPic = transform.scale(pencilPic,(50,45))
txtPic = image.load("Goomba/Mario_Bros_logo.png")
smalltxtPic = transform.scale(txtPic,(500,87))
MlogoPic = image.load("Mario/super-paper-mario.png")
smallMlogoPic = transform.scale(MlogoPic,(100,87))
savePic = image.load("icons/Floppy_disk-512.png")
smallsavePic = transform.scale(savePic,(80,80))
eraserPic = image.load("icons/Pink-eraser.svg.png")
smalleraserPic = transform.scale(eraserPic,(45,45))
openPic = image.load("icons/Open-icon.png")
smallopenPic = transform.scale(openPic,(80,80))
undoPic = image.load("Icons/icon-ios7-undo-512.png")
smallundoPic = transform.scale(undoPic,(95,95))
redoPic = image.load("Icons/redo-icon-24337.png")
smallredoPic = transform.scale(redoPic,(74,74))
stikPic = image.load("Icons/button.png")
smallstikPic = transform.scale(stikPic,(45,45))
circlePic = image.load("Icons/circle-outline.png")
smallcirclePic = transform.scale(circlePic,(50,50))
markerPic = image.load("Icons/CT2016_Icons_HouseholdAndPets_OfficeSupplies_WritingAndCorrection_White.png")
smallmarkerPic = transform.scale(markerPic,(50,50))
sprayPic = image.load("Icons/spray-can-png-2.png")
smallsprayPic = transform.scale(sprayPic,(50,50))
brushPic = image.load("Icons/Paint_Brush_(crop)-icon.png")
smallbrushPic = transform.scale(brushPic,(50,50))
bucketPic = image.load("Icons/Editing-Paint-Bucket-icon.png")
smallbucketPic = transform.scale(bucketPic,(47,47))
clearPic = image.load("Icons/cross-red-256.png")
smallclearPic = transform.scale(clearPic,(40,40))
rainbowPic = image.load("Goomba/Color-circle-icon.png")
smallrainbowPic = transform.scale(rainbowPic,(50,50))
print(9)
marioIcon = transform.scale(marioPic,(60,90))
luigiIcon = transform.scale(luigiPic,(60,90))
toadIcon = transform.scale(toadPic,(60,60))
peachIcon = transform.scale(peachPic,(60,90))
bowserIcon = transform.scale(bowserPic,(60,80))
toadetteIcon = transform.scale(toadettePic,(60,60))
warioIcon = transform.scale(warioPic,(60,70))
waluigiIcon = transform.scale(waluigiPic,(60,90))
starIcon = transform.scale(starPic,(60,70))
blueIcon = transform.scale(bluePic,(60,70))
redIcon = transform.scale(redPic,(60,70))
mushIcon = transform.scale(mushPic,(60,60))
kamekIcon = transform.scale(kamekPic,(60,80))
yoshiIcon = transform.scale(yoshiPic,(60,90))
print(10)
#background
screen.blit(backPic,(0,0))

#rectangles for tools
pencilRect = Rect(10,10,50,50)
eraserRect = Rect(70,10,50,50)
canvasRect = Rect(200,90,990,700)
brushRect = Rect(130,10,50,50)
markerRect = Rect(10,190,50,50)
#infoRect = Rect(10,250,170,160)
clearRect = Rect(10,420,170,40)
fillRect = Rect(70,190,50,50)
rainbowRect = Rect(130,190,50,50)
sprayRect = Rect(10,130,50,50)
colourRect = Rect(10,710,180,180)
colorbox1 = Rect(18,655,164,50)
Cbox = Rect(10,650,180,74)
lineRect = Rect(10,70,50,50)
rectRect = Rect(70,70,50,50)
rect2Rect = Rect(130,70,50,50)
marioRect = Rect(410,800,60,90)
luigiRect = Rect(480,800,60,90)
peachRect = Rect(550,800,60,90)
toadRect = Rect(200,800,60,90)
bowserRect = Rect(270,800,60,90)
toadetteRect = Rect(340,800,60,90)
warioRect = Rect(620,800,60,90)
waluigiRect = Rect(690,800,60,90)
starRect = Rect(760,800,60,90)
blueRect = Rect(830,800,60,90)
mushRect = Rect(900,800,60,90)
redRect = Rect(970,800,60,90)
kamekRect = Rect(1040,800,60,90)
yoshiRect = Rect(1110,800,60,90)
elipseRect = Rect(70,130,50,50)
elipse1Rect = Rect(130,130,50,50)
saveRect = Rect(10,560,80,80)
openRect = Rect(100,560,80,80)
undoRect = Rect(10,470,80,80)
redoRect = Rect(100,470,80,80)


#Canvas
draw.rect(screen,(255,255,255),canvasRect,0)

#black box behind color box
draw.rect(screen,0,Cbox,0)

#Title
screen.blit(smalltxtPic,(310,3))
screen.blit(smallMlogoPic,(770,3))

font.init()
marioFont = font.SysFont("super Mario 256", 15)


c = (0,0,0)# all color starts out as black
count = 0
scales = 100
brushHead = Surface((20,20),SRCALPHA)  #used to make the brush transparent
draw.circle(brushHead,(c[0],c[1],c[2],10),(10,10),10)
root = Tk()
root.withdraw()
width,height = (1200,900)
mx,my = 0,0
undo = []
redo = []
sheet = screen.subsurface(canvasRect).copy()
undo.append(sheet)
tool = "Pencil" #starts program with the pencil tool already selected 
size = 10
start = 0,0
end = 0,0
running =True
while running:
    click = False
    for e in event.get():
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            if e.button == 1:
                start = e.pos
                end = mx,my
                sx,sy = e.pos
                click = True
            if e.button == 4:
                count += 1
                scales += 20
            if e.button == 5:
                count -= 1
                scales -= 20
                
        if e.type == MOUSEBUTTONDOWN:
            click = True
            linePic = screen.copy()
            rectPic = screen.copy()
            circPic = screen.copy()
           
    b = randint(0,16777215)    
    mx,my = mouse.get_pos()
    mb = mouse.get_pressed()
    m = str(mouse.get_pos())
    val = str(count)
    print(mx,my)
    
    #creates and places boxes with icons
    screen.blit(smallwoodPic,(10,250))
    draw.rect(screen,(255,255,255),(10,10,50,50),3)
    screen.blit(smallpencilPic,(9,11))
    draw.rect(screen,(255,255,255),(70,10,50,50),3)
    screen.blit(smalleraserPic,(71,11))
    draw.rect(screen,(255,255,255),rainbowRect,3)
    screen.blit(smallrainbowPic,(130,190))
    draw.rect(screen,(255,255,255),marioRect,3)
    screen.blit(marioIcon,(408,800))
    draw.rect(screen,(255,255,255),brushRect,3)
    screen.blit(smallbrushPic,(130,10))
    draw.rect(screen,(255,255,255),colourRect,3)
    screen.blit(smallcolorPic,(10,710))
    draw.rect(screen,(255,255,255),fillRect,3)
    screen.blit(smallbucketPic,(70,190))
    draw.rect(screen,(255,255,255),luigiRect,3)
    screen.blit(luigiIcon,(480,800))
    draw.rect(screen,(255,255,255),lineRect,3)
    screen.blit(smallstikPic,(11,72))
    draw.rect(screen,(255,255,255),bowserRect,3)
    screen.blit(bowserIcon,(270,800))
    draw.rect(screen,(255,255,255),blueRect,3)
    screen.blit(blueIcon,(830,800))
    draw.rect(screen,(255,255,255),starRect,3)
    screen.blit(starIcon,(760,800))
    draw.rect(screen,(255,255,255),redRect,3)
    screen.blit(redIcon,(970,800))
    draw.rect(screen,(255,255,255),kamekRect,3)
    screen.blit(kamekIcon,(1040,800))
    draw.rect(screen,(255,255,255),yoshiRect,3)
    screen.blit(yoshiIcon,(1110,800))
    draw.rect(screen,(255,255,255),mushRect,3)
    screen.blit(mushIcon,(900,800))
    draw.rect(screen,(255,255,255),peachRect,3)
    screen.blit(peachIcon,(550,800))
    draw.rect(screen,(255,255,255),toadRect,3)
    screen.blit(toadIcon,(200,800))
    draw.rect(screen,(255,255,255),warioRect,3)
    screen.blit(warioIcon,(620,800))
    draw.rect(screen,(255,255,255),waluigiRect,3)
    screen.blit(waluigiIcon,(690,800))
    draw.rect(screen,(255,255,255),toadetteRect,3)
    screen.blit(toadetteIcon,(340,800))
    draw.rect(screen,(255,255,255),rectRect,3)
    draw.rect(screen,0,(75,80,40,30),4)
    draw.rect(screen,(255,255,255),sprayRect,3)
    screen.blit(smallsprayPic,(10,130))
    draw.rect(screen,(255,255,255),markerRect,3)
    screen.blit(smallmarkerPic,(10,190))
    draw.rect(screen,(255,255,255),rect2Rect,3)
    draw.rect(screen,0,(135,80,40,30),0)
    draw.rect(screen,(255,255,255),elipseRect,3)
    draw.circle(screen,0,(95,155),20)
    draw.rect(screen,(255,255,255),elipse1Rect,3)
    screen.blit(smallcirclePic,(130,130))
    draw.rect(screen,(255,255,255),undoRect,3)
    screen.blit(smallundoPic,(3,460))
    draw.rect(screen,(255,255,255),redoRect,3)
    screen.blit(smallredoPic,(102,474))
    #draw.rect(screen,(100,255,100),infoRect,0)
    draw.rect(screen,(117,117,117),clearRect,0)
    screen.blit(smallclearPic,(75,420))
    draw.rect(screen,(255,255,255),saveRect,3)
    screen.blit(smallsavePic,(10,560))
    draw.rect(screen,(255,255,255),openRect,3)
    screen.blit(smallopenPic,(105,560))

    #Undo/Redo
##    if e.type == MOUSEBUTTONUP:
##        mouse.set_visible(True)
##        umx,umy = mouse.get_pos()
##    if e.type == MOUSEBUTTONUP:
##        #when mouse is up, screen is copied
##        if canvasRect.collidepoint(mx,my) and (e.button == 1 or e.button == 3):
##            edit = screen.subsurface(canvasRect).copy()
##            undo.append(edit)
##    if e.type == MOUSEBUTTONDOWN and e.button == 1:
##        if undoRect.collidepoint(mx,my):
##            if len(undo) > 1:
##                redo.append(undo[-1])
##                undo.remove(undo[-1])
##                screen.blit(undo[-1],(200,10))
##        if redoRect.collidepoint(mx,my):
##            if len(redo) > 0:
##                undo.append(redo[-1])
##                redo.remove(redo[-1])
##                screen.blit(redo[-1],(200,10))
##    
   
    #selcting the Tools
    if mb[0] == 1 and eraserRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),eraserRect,3) #changes colour of box when its selected
        tool = "Eraser" #changes tool variable to the tool the user has selcted
    if mb[0] == 1 and pencilRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),pencilRect,3)
        tool = "Pencil"
    if mb[0] == 1 and clearRect.collidepoint(mx,my):
        draw.rect(screen,(37,37,37),clearRect,0)
        screen.blit(smallclearPic,(75,420))
        draw.rect(screen,(255,255,255),canvasRect,0)
    if mb[0] == 1 and fillRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),fillRect,3)
        tool = "Bucket"
    if mb[0] == 1 and marioRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),marioRect,3)
        tool = "Mario"
    if mb[0] == 1 and yoshiRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),yoshiRect,3)
        tool = "Yoshi"
    if mb[0] == 1 and kamekRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),kamekRect,3)
        tool = "Kamek"
    if mb[0] == 1 and redRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),redRect,3)
        tool = "Red Flower"
    if mb[0] == 1 and mushRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),mushRect,3)
        tool = "Mushroom"
    if mb[0] == 1 and blueRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),blueRect,3)
        tool = "Blue Flower"
    if mb[0] == 1 and starRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),starRect,3)
        tool = "Star"
    if mb[0] == 1 and warioRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),warioRect,3)
        tool = "Wario"
    if mb[0] == 1 and waluigiRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),waluigiRect,3)
        tool = "Waluigi"
    if mb[0] == 1 and colourRect.collidepoint(mx,my):
        c = screen.get_at((mx,my))
        draw.rect(screen,c,colorbox1,0)
        brushHead = Surface((20,20),SRCALPHA) 
        draw.circle(brushHead,(c[0],c[1],c[2],10),(10,10),10)
    if mb[0] == 1 and luigiRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),luigiRect,3)
        tool = "Luigi"
    if mb[0] == 1 and lineRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),lineRect,3)
        tool = "Line"
    if mb[0] == 1 and brushRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),brushRect,3)
        tool = "Brush"
    if mb[0] == 1 and markerRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),markerRect,3)
        tool = "Marker"
    if mb[0] == 1 and peachRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),peachRect,3)
        tool = "Peach"
    if mb[0] == 1 and bowserRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),bowserRect,3)
        tool = "Bowser"
    if mb[0] == 1 and toadRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),toadRect,3)
        tool = "Toad"
    if mb[0] == 1 and toadetteRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),toadetteRect,3)
        tool = "Toadette"
    if mb[0] == 1 and sprayRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),sprayRect,3)
        tool = "Spray"
    if mb[0] == 1 and rectRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),rectRect,3)
        tool = "Rect"
    if mb[0] == 1 and rainbowRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),rainbowRect,3)
        tool = "Rainbow"
    if mb[0] == 1 and rect2Rect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),rect2Rect,3)
        tool = "Fill Rect"
    if mb[0] == 1 and elipseRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),elipseRect,3)
        tool = "Fill Circle"
    if mb[0] == 1 and elipse1Rect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),elipse1Rect,3)
        tool = "Circle"
    if mb[0] == 1 and saveRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),saveRect,3)
        try:
                result = filedialog.asksaveasfilename(defaultextension="*.png") #asks user what they want to name the file
                image.save(screen.subsurface(canvasRect),result) #saves canvas as file named by user
        except:
                pass
    if mb[0] == 1 and openRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),openRect,3)
        try:
                screen.set_clip(canvasRect)
                load = filedialog.askopenfilename() #asks user for file name
                file = image.load(load)
                screen.blit(file,(canvasRect)) #blits the picture they opened in the canvas
        except:
                pass
    if e.type == MOUSEBUTTONUP and canvasRect.collidepoint(mx,my):
        edit = screen.subsurface(canvasRect).copy()
        undo.append(edit)
    if mb[0] == 1 and undoRect.collidepoint(mx,my):
        if len(undo) > 0:
            redo.append(undo[-1])
            screen.blit(undo[len(undo)-1],(canvasRect))
            undo.remove(undo[-1])
    if mb[0] == 1 and redoRect.collidepoint(mx,my):
        if len(redo) > 0:
            undo.append(redo[-1])
            screen.blit(redo[len(redo)-1],(canvasRect))
            redo.remove(redo[-1])


    toolPic = marioFont.render("Tool: ", True, (200, 81, 32))
    txtPic = marioFont.render(tool, True, (255,255,0))
    mousePic = marioFont.render("Mouse: ", True, (200, 81, 32))
    mPic = marioFont.render(m, True, (255,255,0))
    countPic = marioFont.render("Wheel Value: ", True, (200,81,32))
    valPic = marioFont.render(val, True, (255,255,0))
    screen.blit(txtPic,(19,295))
    screen.blit(toolPic,(17,273))
    screen.blit(mPic,(17,375))
    screen.blit(mousePic,(22,355))
    screen.blit(countPic,(19,320))
    screen.blit(valPic,(19,340))
       
    
        
    
        
        
        
        
    
        
        

        

    # using the tools
    
    if mb[0] == 1 and canvasRect.collidepoint(mx,my):
        screen.set_clip(canvasRect)
        if tool == "Pencil":
            draw.line(screen,c,(oldmx,oldmy),(mx,my),4)
        if tool == "Marker":
            draw.circle(screen,c,(mx,my),10+count)
        if tool == "Rainbow":
            draw.circle(screen,b,(mx,my),20+count)
        if tool == "Eraser":
            draw.circle(screen,(255,255,255),(mx,my),5+count)
        if tool == "Line":
            screen.blit(linePic,(0,0))
            draw.line(screen, c, start,(mx,my), 10+count)
        if tool == "Spray":
            for i in range (size*2):
                ax = randint(mx-size,mx+size)
                ay = randint(my-size,my+size)
            dist = hypot(mx-ax,my-ay)
            if dist <= size:
                draw.circle(screen,c,(ax,ay),0)
        if tool == "Brush":
            dx = mx - oldmx
            dy = my - oldmy
            dist = hypot(dx,dy)
            screen.blit(brushHead,(mx-5,my-5))
            for i in range(int(dist)):
                dotX = i*dx/dist+oldmx
                dotY = i*dy/dist+oldmy
                screen.blit(brushHead,(int(dotX)-5,int(dotY)-5))
        if tool == "Rect":
            screen.blit(rectPic,(0,0))
            a = mx - sx
            b = my - sy
            draw.rect(screen,c,(sx,sy,a,b),3)
        if tool == "Fill Rect":
            screen.blit(rectPic,(0,0))
            a = mx - sx
            b = my - sy
            draw.rect(screen,c,(sx,sy,a,b),0)
        if tool == "Fill Circle":
            screen.blit(circPic,(0,0))
            ERect = Rect(sx,sy,mx-sx,my-sy)
            ERect.normalize()
            draw.ellipse(screen,c,(ERect))
        if tool == "Circle":
            screen.blit(circPic,(0,0))
            ERect = Rect(sx,sy,mx-sx,my-sy)
            ERect.normalize()
            if ERect.width<4*2 or ERect.height<4*2:
                draw.ellipse(screen,c,(ERect))
            else:
                draw.ellipse(screen,c,(ERect),2)
        if tool == "Bucket":
            fill = screen.get_at((mx,my))
            area = [(mx,my)]
            while len(area)>0:
                newarea = []
                for fx,fy in area:
                    if 0 < fx < width and 0 < fy < height and screen.get_at((fx,fy)) == fill:
                        screen.set_at((fx,fy), c)
                        newarea += [(fx+1,fy),(fx-1,fy),(fx,fy-1),(fx,fy+1)]
                    area = newarea
        
        
            
            
    
            
    #STAMPS     
        screen.set_clip(None)
    if click and canvasRect.collidepoint(mx,my):
        screen.set_clip(canvasRect)
        if tool == "Luigi":
            smalluigiPic = transform.smoothscale(smallluigiPic,(scales//2,scales))
            screen.blit(smalluigiPic,(mx-smalluigiPic.get_width()//2,my-smalluigiPic.get_height()//2))
        if tool == "Mario":
            smamarioPic = tranform.smoothscale(smallmarioPic,(scales//2,scales))
            screen.blit(smamarioPic,(mx-smamarioPic.get_width()//2,my-smamarioPic.get_height()//2))
        if tool == "Peach":
            smapeachPic = tranform.smoothscale(smallpeachPic,(scales//2,scales))
            screen.blit(smapeachPic,(mx-smapeachPic.get_width()//2,my-smapeachPic.get_height()//2))
        if tool == "Toad":
            smatoadPic = transform.smoothscale(smalltoadPic,(scales//2,scales))
            screen.blit(smatoadPic,(mx-smatoadPic.get_width()//2,my-smatoadPic.get_height()//2))
        if tool == "Bowser":
            smabowserPic = transform.smoothscale(smallbowserPic,(scales//2,scales))
            screen.blit(smabowserPic,(mx-smabowserPic.get_width()//2,my-smabowserPic.get_height()//2))
        if tool == "Toadette":
            smatoadettePic = transform.smoothscale(smalltoadettePic,(scales//2,scales))
            screen.blit(smatoadettePic,(mx-smatoadettePic.get_width()//2,my-smatoadettePic.get_height()//2))
        if tool == "Wario":
            smawarioPic = transform.smoothscale(smallwarioPic,(scales//2,scales))
            screen.blit(smawarioPic,(mx-smawarioPic.get_width()//2,my-smawarioPic.get_height()//2))
        if tool == "Waluigi":
            smawaluigiPic = transform.smoothscale(smallwaluigiPic,(scales//2,scales))
            screen.blit(smawaluigiPic,(mx-smawaluigiPic.get_width()//2,my-smawaluigiPic.get_height()//2))
        if tool == "Star":
            smastarPic = transform.smoothscale(smallstarPic,(scales//2,scales))
            screen.blit(smastarPic,(mx-smastarPic.get_width()//2,my-smastarPic.get_height()//2))
        if tool == "Blue Flower":
            smabluePic = transform.smoothscale(smallbluePic,(scales//2,scales))
            screen.blit(smabluePic,(mx-smabluePic.get_width()//2,my-smabluePic.get_height()//2))
        if tool == "Mushroom":
            smamushPic = transform.smoothscale(smallmushPic,(scales//2,scales))
            screen.blit(smamushPic,(mx-smamushPic.get_width()//2,my-smamushPic.get_height()//2))
        if tool == "Red Flower":
            smaredPic = transform.smoothscale(smallredPic,(scales//2,scales))
            screen.blit(smaredPic,(mx-smaredPic.get_width()//2,my-smaredPic.get_height()//2))
        if tool == "Kamek":
            smakamekPic = transform.smoothscale(smallkamekPic,(scales//2,scales))
            screen.blit(smakamekPic,(mx-smakamekPic.get_width()//2,my-smakamekPic.get_height()//2))
        if tool == "Yoshi":
            smayoshiPic = transform.smoothscale(smallyoshiPic,(scales//2,scales))
            screen.blit(smayoshiPic,(mx-smayoshiPic.get_width()//2,my-smayoshiPic.get_height()//2))
       
        
            

        
        screen.set_clip(None)
    

            
       
    oldmx = mx
    oldmy = my
    
    display.flip()

quit()


