from pygame import*
from random import*
from math import*
from tkinter import*
screen = display.set_mode((1100,900))
#pictures
colorPic = image.load("Goomba/atari-256-colour-palette.png")
smallcolorPic = transform.scale(colorPic,(180,180))
#smallcolourPic = image.load("Goomba/color_wheel.png")
#smallcolourPic = transform.scale(colourPic,(170,170))
#image.save(smallcolourPic,"Goomba/color_wheel.png")
print(1)
marioPic = image.load("Mario/386px-Mario.PNG")
print(2)
smallmarioPic = transform.scale(marioPic,(150,150))
#image.save(smallmarioPic,"Mario/386px-Mario.PNG")
smallbackPic = image.load("Goomba/New-super-mario-bros.jpg")
print(3)
backPic = transform.scale(smallbackPic,(1100,900))
#image.save(smallbackPic,"Goomba/New-super-mario-bros.png")
luigiPic = image.load("Luigi/SM3DL2_Luigi.png")
smallluigiPic = transform.scale(luigiPic,(150,150))
print(3)
#bowserPic = image.load("Bowser/Bowser_-_Super_Smash_Bros..png")
#smallbowserPic = transform.scale(bowserPic,(150,160))
print(3)
#peachPic = image.load("Peach/Princess_Peach_NSMBW.png")
#smallpeachPic = transform.scale(peachPic,(120,150))
print(3)
#toadPic = image.load("Toad/captain_toad_transparent_by_mach_7-d9h8jcl.png")
#smalltoadPic = transform.scale(toadPic,(150,150))
#print(3)
#toadettePic = image.load("Toad/Toadette_-_Mario_Party_10.png")
#smalltoadettePic = transform.scale(toadettePic,(150,150))
#print(3)
pencilPic = image.load("Icons/pencil-icon-512-17.png")
smallpencilPic = transform.scale(pencilPic,(50,45))
txtPic = image.load("Goomba/Mario_Bros_logo.png")
smalltxtPic = transform.scale(txtPic,(500,87))
MlogoPic = image.load("Mario/super-paper-mario.png")
smallMlogoPic = transform.scale(MlogoPic,(100,87))
print(3)

#background
screen.blit(backPic,(0,0))
#Tools
pencilRect = Rect(10,10,50,50)
eraserRect = Rect(70,10,50,50)
canvasRect = Rect(200,90,890,700)
brushRect = Rect(130,10,50,50)
sprayRect = Rect(10,130,50,50)
colourRect = Rect(10,710,180,180)
colorbox1 = Rect(18,655,164,50)
colorbox2 = Rect(100,315,80,50)
Cbox = Rect(10,650,180,74)
lineRect = Rect(10,70,50,50)
rectRect = Rect(70,70,50,50)
rect2Rect = Rect(130,70,50,50)
marioRect = Rect(410,800,60,90)
luigiRect = Rect(480,800,60,90)
peachRect = Rect(550,800,60,90)
toadRect = Rect(200,800,60,90)
bowserRect = Rect(270,800,60,90)
toadetteRect = Rect(340,800,60,90)
warioRect = Rect(620,800,60,90)
waluigiRect = Rect(690,800,60,90)
starRect = Rect(550,800,60,90)
elipseRect = Rect(70,130,50,50)
elipse1Rect = Rect(130,130,50,50)
saveRect = Rect(10,560,80,80)
undoRect = Rect(110,560,80,80)


#Tool boxes
draw.rect(screen,(255,255,255),canvasRect,0)
draw.rect(screen,0,Cbox,0)


#Title Text
#font.init()
#helFont = font.SysFont("Arial",50)
#txtPic = helFont.render("Mario Paint", True, (255,0,0))
#screen.blit(txtPic,(300,20))


screen.blit(smalltxtPic,(310,3))
screen.blit(smallMlogoPic,(770,3))
c = (0,0,0)
count = 0
##cover = Surface((50,50)).convert()                
##cover.set_alpha(5)
##cover.fill((255,0,255)) 
##cover.set_colorkey((255,0,255))
##draw.circle(cover,c,(25,25),24)
brushHead = Surface((20,20),SRCALPHA)
draw.circle(brushHead,(c[0],c[1],c[2],10),(10,10),10)

root = Tk()
root.withdraw()
mx,my = 0,0
undo = []
tool = "pencil"
b = 0
size = 10
start = 0,0
end = 0,0
running =True
while running:
    click = False
    for e in event.get():
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            if e.button == 1:
                start = e.pos
                end = mx,my
                sx,sy = e.pos
                click = True
            if e.button == 4:
                count += 1
            if e.button == 5:
                count -= 1
                
        if e.type == MOUSEBUTTONDOWN:
            click = True
            linePic = screen.copy()
            rectPic = screen.copy()
            circPic = screen.copy()
           
            
    mx,my = mouse.get_pos()
    mb = mouse.get_pressed()
    print(mx,my)
    #boxes
    draw.rect(screen,(255,255,255),(10,10,50,50),1)
    screen.blit(smallpencilPic,(10,10))
    draw.rect(screen,(255,255,255),(70,10,50,50),1)
    draw.rect(screen,(255,255,255),marioRect,1)
    draw.rect(screen,(255,255,255),brushRect,1)
    draw.rect(screen,(255,255,255),colourRect,1)
    draw.rect(screen,(255,255,255),luigiRect,1)
    draw.rect(screen,(255,255,255),lineRect,1)
    draw.rect(screen,(255,255,255),bowserRect,1)
    draw.rect(screen,(255,255,255),peachRect,1)
    draw.rect(screen,(255,255,255),toadRect,1)
    draw.rect(screen,(255,255,255),toadetteRect,1)
    draw.rect(screen,(255,255,255),rectRect,1)
    draw.rect(screen,(255,255,255),sprayRect,1)
    draw.rect(screen,(255,255,255),rect2Rect,1)
    draw.rect(screen,(255,255,255),elipseRect,1)
    draw.rect(screen,(255,255,255),elipse1Rect,1)
    draw.rect(screen,(255,255,255),saveRect,1)
    draw.rect(screen,(255,255,255),undoRect,1)
    screen.blit(smallcolorPic,(10,710))
    #selcting Tools
    if mb[0] == 1 and eraserRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),eraserRect,1)
        tool = "eraser"
    if mb[0] == 1 and pencilRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),pencilRect,1)
        tool = "pencil"
    if mb[0] == 1 and marioRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),marioRect,1)
        tool = "mario"
    if mb[0] == 1 and colourRect.collidepoint(mx,my):
        c = screen.get_at((mx,my))
        draw.rect(screen,c,colorbox1,0)
        brushHead = Surface((20,20),SRCALPHA)
        draw.circle(brushHead,(c[0],c[1],c[2],10),(10,10),10)
    if mb[0] == 1 and luigiRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),luigiRect,1)
        tool = "luigi"
    if mb[0] == 1 and lineRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),lineRect,1)
        tool = "line"
    if mb[0] == 1 and brushRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),brushRect,1)
        tool = "brush"
    if mb[0] == 1 and peachRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),peachRect,1)
        tool = "peach"
    if mb[0] == 1 and bowserRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),bowserRect,1)
        tool = "bowser"
    if mb[0] == 1 and toadRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),toadRect,1)
        tool = "toad"
    if mb[0] == 1 and toadetteRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),toadetteRect,1)
        tool = "toadette"
    if mb[0] == 1 and sprayRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),sprayRect,1)
        tool = "spray"
    if mb[0] == 1 and rectRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),rectRect,1)
        tool = "rect"
    if mb[0] == 1 and rect2Rect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),rect2Rect,1)
        tool = "rect1"
    if mb[0] == 1 and elipseRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),elipseRect,1)
        tool = "elipse"
    if mb[0] == 1 and elipse1Rect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),elipse1Rect,1)
        tool = "elipse1"
    if mb[0] == 1 and saveRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),saveRect,1)
        tool = "save"
    if mb[0] == 1 and undoRect.collidepoint(mx,my):
        draw.rect(screen,(255,255,0),undoRect,1)
        tool = "undo"
    if mb[0] == 1 and canvasRect.collidepoint(mx,my):
        undo.append(screen.copy())
        print(undo)
        
    
        
        
    if tool == "save":
        try:
                result = filedialog.asksaveasfilename(defaultextension="*.PNG")
                image.save(screen.subsurface(canvasRect),result)
        except:
                pass
        
    
        
        

        

    # use the tools
    
    if mb[0] == 1 and canvasRect.collidepoint(mx,my):
        screen.set_clip(canvasRect)
        if tool == "pencil":
            draw.line(screen,c,(oldmx,oldmy),(mx,my),4+count)
        if tool == "eraser":
            draw.circle(screen,(255,255,255),(mx,my),5+count)
        if tool == "line":
            screen.blit(linePic,(0,0))
            draw.line(screen, c, start,(mx,my), 10+count)
        #if tool == "save":
         #   try:
          #      result = filedialog.asksaveasfilename(defaultextension="*.PNG")
           #     image.save(screen.subsurface(canvasRect),result)
            #except:
             #   pass
        if tool == "spray":
            for i in range (size*2):
                ax = randint(mx-size,mx+size)
                ay = randint(my-size,my+size)
            dist = hypot(mx-ax,my-ay)
            if dist <= size:
                draw.circle(screen,c,(ax,ay),0)
        if tool == "brush":
            dx = mx - oldmx
            dy = my - oldmy
            dist = hypot(dx,dy)
            screen.blit(brushHead,(mx-5,my-5))
            for i in range(int(dist)):
                dotX = i*dx/dist+oldmx
                dotY = i*dy/dist+oldmy
                screen.blit(brushHead,(int(dotX)-5,int(dotY)-5))
        if tool == "rect":
            screen.blit(rectPic,(0,0))
            a = mx - sx
            b = my - sy
            draw.rect(screen,c,(sx,sy,a,b),1+count)
        if tool == "rect1":
            screen.blit(rectPic,(0,0))
            a = mx - sx
            b = my - sy
            draw.rect(screen,c,(sx,sy,a,b),0)
        if tool == "elipse":
            screen.blit(circPic,(0,0))
            ERect = Rect(sx,sy,mx-sx,my-sy)
            ERect.normalize()
            draw.ellipse(screen,c,(ERect))
        if tool == "elipse1":
            screen.blit(circPic,(0,0))
            ERect = Rect(sx,sy,mx-sx,my-sy)
            ERect.normalize()
            if ERect.width<4*2 or ERect.height<4*2:
                draw.ellipse(screen,c,(ERect))
            else:
                draw.ellipse(screen,c,(ERect),2)
        if tool == "undo":
        
            
            

            
            
        screen.set_clip(None)
    if click and canvasRect.collidepoint(mx,my):
        screen.set_clip(canvasRect)
        if tool == "luigi":            
            screen.blit(smallluigiPic,(mx-smallluigiPic.get_width()//2,my-smallluigiPic.get_height()//2))
        if tool == "mario":            
            screen.blit(smallmarioPic,(mx-smallmarioPic.get_width()//2,my-smallmarioPic.get_height()//2))
        if tool == "peach":            
            screen.blit(smallpeachPic,(mx-smallpeachPic.get_width()//2,my-smallpeachPic.get_height()//2))
        if tool == "toad":            
            screen.blit(smalltoadPic,(mx-smalltoadPic.get_width()//2,my-smalltoadPic.get_height()//2))
        if tool == "bowser":            
            screen.blit(smallbowserPic,(mx-smallbowserPic.get_width()//2,my-smallbowserPic.get_height()//2))
        if tool == "toadette":
            
            screen.blit(smalltoadettePic,(mx-smalltoadettePic.get_width()//2,my-smalltoadettePic.get_height()//2))
       
        
            

        
        screen.set_clip(None)
    

            
       
    oldmx = mx
    oldmy = my
    
    display.flip()

quit()


